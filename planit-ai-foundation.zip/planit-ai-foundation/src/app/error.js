"use client";

export default function Error({ error, reset }) {
  return (
    <div
      className="container"
      style={{ paddingBlock: "var(--space-6)", textAlign: "center" }}
    >
      <h1>Something went wrong</h1>
      <p style={{ color: "var(--color-text-muted)" }}>
        {error?.message || "An unexpected error occurred."}
      </p>
      <button
        className="btn btn-primary"
        onClick={() => reset()}
        style={{ marginTop: "var(--space-3)" }}
      >
        Try again
      </button>
    </div>
  );
}
