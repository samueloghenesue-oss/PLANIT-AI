import Spinner from "@/components/ui/Spinner";

export default function Loading() {
  return (
    <div style={{ display: "grid", placeItems: "center", minHeight: "50vh" }}>
      <Spinner />
    </div>
  );
}
