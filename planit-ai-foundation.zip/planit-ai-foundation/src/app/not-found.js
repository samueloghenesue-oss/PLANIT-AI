import Link from "next/link";

export default function NotFound() {
  return (
    <div
      className="container"
      style={{ paddingBlock: "var(--space-6)", textAlign: "center" }}
    >
      <h1>Page not found</h1>
      <p style={{ color: "var(--color-text-muted)" }}>
        The page you&apos;re looking for doesn&apos;t exist.
      </p>
      <Link href="/">Go home</Link>
    </div>
  );
}
