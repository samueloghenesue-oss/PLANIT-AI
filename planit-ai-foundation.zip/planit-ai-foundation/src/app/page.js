import { BRAND } from "@/lib/constants";
import Logo from "@/components/layout/Logo";
import Card from "@/components/ui/Card";

export default function HomePage() {
  return (
    <main className="container" style={{ paddingBlock: "var(--space-6)" }}>
      <Logo />
      <Card style={{ marginTop: "var(--space-4)" }}>
        <h1 style={{ marginTop: 0 }}>{BRAND.name}</h1>
        <p style={{ color: "var(--color-text-muted)" }}>{BRAND.tagline}</p>
        <p style={{ fontSize: "0.875rem", color: "var(--color-text-muted)" }}>
          Foundation build — the real landing page comes next.
        </p>
      </Card>
    </main>
  );
}
