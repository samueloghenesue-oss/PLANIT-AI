export default function Logo({ size = 28 }) {
  return (
    <div style={{ display: "inline-flex", alignItems: "center", gap: "8px" }}>
      {/* TEMPORARY placeholder mark — replace with the real PLANIT AI logo when supplied */}
      <svg width={size} height={size} viewBox="0 0 32 32" fill="none" aria-hidden="true">
        <rect width="32" height="32" rx="8" fill="var(--color-accent)" />
        <path
          d="M9 22V10h7a4 4 0 1 1 0 8H9"
          stroke="var(--color-bg)"
          strokeWidth="2.5"
          fill="none"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
      <span style={{ fontWeight: 700, fontSize: "1.0625rem", letterSpacing: "-0.01em" }}>
        PLANIT <span style={{ color: "var(--color-accent)" }}>AI</span>
      </span>
    </div>
  );
}
