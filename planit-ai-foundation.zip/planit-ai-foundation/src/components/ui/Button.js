"use client";

export default function Button({
  children,
  variant = "primary",
  as: Component = "button",
  className = "",
  ...props
}) {
  const classes = `btn btn-${variant} ${className}`.trim();
  return (
    <Component className={classes} {...props}>
      {children}
    </Component>
  );
}
